#!/usr/bin/env bash
set -u

ROOT_DIR=/workdir/PERIOD
EVIDENCE=/evidence
RESULTS="$EVIDENCE/results"
mkdir -p "$RESULTS"

run_step() {
  local name="$1"
  shift
  local folder="$RESULTS/$name"
  mkdir -p "$folder"
  printf '%q ' "$@" > "$folder/command.txt"
  printf '\n' >> "$folder/command.txt"
  "$@" > "$folder/console.log" 2>&1
  local status=$?
  printf '%s\n' "$status" > "$folder/exit-code.txt"
  return 0
}

run_shell_step() {
  local name="$1"
  local command="$2"
  local folder="$RESULTS/$name"
  mkdir -p "$folder"
  printf '%s\n' "$command" > "$folder/command.txt"
  bash -lc "$command" > "$folder/console.log" 2>&1
  local status=$?
  printf '%s\n' "$status" > "$folder/exit-code.txt"
  return 0
}

date --iso-8601=seconds > "$EVIDENCE/started-at.txt"

run_shell_step environment "source '$ROOT_DIR/tool/init_env.sh' && cd '$ROOT_DIR/test/doubleFree' && uname -a && clang --version && python3 --version"
run_shell_step clean "source '$ROOT_DIR/tool/init_env.sh' && cd '$ROOT_DIR/test/doubleFree' && ./cleanDIR.sh"
run_shell_step bitcode "source '$ROOT_DIR/tool/init_env.sh' && cd '$ROOT_DIR/test/doubleFree' && clang -g -emit-llvm -c ./df.c -o df.bc"
run_shell_step static-analysis "source '$ROOT_DIR/tool/init_env.sh' && cd '$ROOT_DIR/test/doubleFree' && \"\$ROOT_DIR/tool/staticAnalysis/staticAnalysis.sh\" df"
run_shell_step instrument "source '$ROOT_DIR/tool/init_env.sh' && cd '$ROOT_DIR/test/doubleFree' && export Con_PATH=\"\$ROOT_DIR/test/doubleFree/ConConfig.df\" && \"\$ROOT_DIR/tool/staticAnalysis/DBDS-INSTRU/dbds-clang-fast\" -g -fsanitize=address -c ./df.c -o df.o"
run_shell_step link "source '$ROOT_DIR/tool/init_env.sh' && cd '$ROOT_DIR/test/doubleFree' && clang++ ./df.o \"\$ROOT_DIR/tool/staticAnalysis/DBDS-INSTRU/DBDSFunction.o\" -g -o df -lpthread -fsanitize=address -ldl"
run_shell_step explore "source '$ROOT_DIR/tool/init_env.sh' && cd '$ROOT_DIR/test/doubleFree' && python3 -u \"\$ROOT_DIR/tool/DBDS/run_PDS.py\" -y -d 3 ./df"

error_file="$ROOT_DIR/test/doubleFree/out_df_1/Errors/000001_0000003_double-free"
if [ -f "$error_file" ]; then
  mkdir -p "$EVIDENCE/raw-output"
  cp -a "$ROOT_DIR/test/doubleFree/out_df_1/." "$EVIDENCE/raw-output/"
  run_shell_step replay "source '$ROOT_DIR/tool/init_env.sh' && cd '$ROOT_DIR/test/doubleFree' && python3 -u \"\$ROOT_DIR/tool/DBDS/run_PDS.py\" -r '$error_file' ./df"
else
  mkdir -p "$RESULTS/replay"
  printf 'required replay input was not generated: %s\n' "$error_file" > "$RESULTS/replay/console.log"
  printf '1\n' > "$RESULTS/replay/exit-code.txt"
fi

run_shell_step sched-deadline "chrt -d -T 1000000 -D 10000000 -P 10000000 0 chrt -p 0"
date --iso-8601=seconds > "$EVIDENCE/finished-at.txt"
