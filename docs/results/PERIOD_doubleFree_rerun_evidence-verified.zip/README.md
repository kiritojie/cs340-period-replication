# PERIOD doubleFree 最小实验交接

本目录是 2026-11-15 在 Windows WSL2 的 Podman 环境中完成的一轮新实验记录。使用的镜像为 `docker.io/wcventure/period@sha256:8f47d8b9148f2db579627842026e722d0f205ddeab13e70ee41a8df3dbd59fbc`。镜像完整 ID、digest、标签和架构信息在 `image-inspect.log`。

将同目录的 `PERIOD-amd64.oci.tar` 发给接收方，并执行：

```bash
podman load -i PERIOD-amd64.oci.tar
```

## 结果

| 阶段 | 退出码 | 结果 |
| --- | ---: | --- |
| clean、bitcode、静态分析、插桩、链接 | 0 | `df` 成功构建，使用 ASan。 |
| explore | 0 | 共 6 个调度，首次错误为第 3 个，4 个 double-free，0 个超时。 |
| replay | 0 | 对第一个保存的错误调度回放，输出 `AddressSanitizer: double-free`。 |
| sched-deadline | 0 | 读回策略为 `SCHED_DEADLINE`，runtime/deadline/period 为 1/10/10 ms。 |

每一步的准确命令、标准输出和错误输出、退出码位于 `results/<步骤>/`。`raw-output/Errors/` 保存本轮探索生成的 4 份原始错误调度文件。`outer-command.txt`、`outer-console.log` 和 `outer-exit-code.txt` 记录容器外层调用。该运行使用禁网的临时特权容器，不修改已存在的 PERIOD 容器。

`explore` 和 `replay` 的退出码属于 `run_PDS.py` 驱动。它们为 0，表示驱动完成；被测 `df` 在错误调度下被 AddressSanitizer 终止，相关 ASan 输出位于 `results/replay/console.log`，探索过程记录的目标状态集合为 `[0, -6]`。

`run_doublefree_capture.sh` 是生成本目录的捕获脚本。它执行论文作者 `doubleFree` 示例中的 bitcode、静态分析、插桩、ASan 链接、PERIOD 探索和保存的错误调度回放步骤。
