# Frozen reorder_3 formal results

Six accepted unified-driver formal rounds are indexed by exact repository-relative file hashes in FREEZE.json. The original evidence remains in its existing results directories; statistics/ is a byte-preserved snapshot. Later other-benchmark results may be added to the same session without replacing these six rounds.
