#!/usr/bin/env python3
"""Validate preserved reorder_3 logs without executing PERIOD or its target."""
from __future__ import print_function

import argparse
import ast
import hashlib
import importlib.util
import itertools
import json
import re
import sys
from pathlib import Path

ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
TEST = re.compile(r"^\s*test (\d+)(?: for prefix .*?)?:\s*(\[\[.*\]\])\s*$")
ERROR_FILE = re.compile(r"^\d{6}_(\d{7})_assertion-failed$")
EXPECTED_ERROR_ORDINALS = [6, 7, 19, 20, 24, 25]
KPS = [2, 2, 1]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def yield_pattern(schedule):
    # Mirrors pinned bp_sched.py:get_yield_pattern, with driver's zero-padding.
    result = [[0] * count for count in KPS]
    indices = [0] * len(KPS)
    for period in schedule:
        for thread in period:
            indices[thread] += 1
        for thread in range(len(KPS)):
            if indices[thread] < len(result[thread]):
                result[thread][indices[thread]] += 1
    for row in result:
        row.extend([0] * (2 - len(row)))
    return result


def valid_schedule(value, mode):
    require(isinstance(value, list) and value, "schedule is not a nonempty list")
    totals = [0, 0, 0]
    for period in value:
        require(isinstance(period, list) and period, "empty or invalid period")
        for thread in period:
            require(type(thread) is int and 0 <= thread < 3, "invalid thread ID")
            totals[thread] += 1
    require(totals == KPS, "schedule does not contain exactly [2,2,1] key points")
    if mode == "serial":
        require(3 <= len(value) <= 5, "serial period count outside depth-3 window")
        require(all(len(set(period)) == 1 for period in value), "serial period mixes threads")
        require(all(left[0] != right[0] for left, right in zip(value, value[1:])),
                "serial adjacent periods repeat a thread")
    else:
        require(2 <= len(value) <= 4, "parallel period count outside depth-3 window")
        require(all(len(set(period)) == 1 for period in value[:-1]),
                "parallel non-final period mixes threads")
        require(all(left[0] != right[0] for left, right in zip(value[:-2], value[1:-1])),
                "parallel adjacent controlled periods repeat a thread")
        require(value[-2][0] not in value[-1], "parallel final period repeats the preceding thread")


def one_value(matches, label):
    require(len(matches) == 1, "missing or repeated " + label)
    return int(matches[0])


def actual_yield_trace(run, schedules):
    path = run / "actual-yield.jsonl"
    require(path.is_file(), "missing actual memmove_pattern_list observation trace")
    records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    starts = [record for record in records if record.get("event") == "trace_start"]
    summaries = [record for record in records if record.get("event") == "trace_summary"]
    writes = [record for record in records if record.get("event") == "yield_write"]
    require(len(starts) == 1 and len(summaries) == 1, "incomplete or duplicated observation trace")
    require(starts[0].get("schema") == "cs340-period-yield-trace-v1", "unsupported observation trace schema")
    require(isinstance(starts[0].get("expected_source"), str) and bool(starts[0]["expected_source"]),
            "observation trace lacks its official source namespace")
    require(re.match(r"^[0-9a-f]{64}$", starts[0].get("expected_source_sha256", "")) is not None and
            re.match(r"^[0-9a-f]{64}$", starts[0].get("driver_sha256", "")) is not None,
            "observation trace lacks source/entry-driver identity hashes")
    require(records[0].get("event") == "trace_start" and records[-1].get("event") == "trace_summary",
            "observation trace has invalid event order")
    require(all(record.get("event") in ("trace_start", "yield_write", "trace_summary") for record in records),
            "observation trace records an error or unsupported event")
    require(summaries[0].get("driver_exit_code") == 0 and summaries[0].get("yield_writes") == len(writes),
            "observer/driver did not complete successfully")
    require(summaries[0].get("pending_writes") == 0 and summaries[0].get("observation_error") is None,
            "observer reports unfinished writes or an observation failure")
    require(len(writes) == len(schedules), "actual yield-write count differs from executed schedules")
    patterns = []
    for ordinal, (record, schedule) in enumerate(zip(writes, schedules), 1):
        require(record.get("ordinal") == ordinal and record.get("schedule") == schedule,
                "actual write ordinal/schedule differs from stdout")
        require(record.get("period") == len(schedule), "actual write period differs from printed schedule")
        require(record.get("source_file") == starts[0].get("expected_source"),
                "actual write came from a different driver source namespace")
        pattern = record.get("yield_pattern")
        require(isinstance(pattern, list) and len(pattern) == 3 and
                all(isinstance(row, list) and len(row) == 2 and
                    all(type(value) is int and 0 <= value <= 65535 for value in row) for row in pattern),
                "actual yield matrix is not a padded uint16 3x2 matrix")
        require(pattern == yield_pattern(schedule), "actual yield matrix differs from official conversion")
        patterns.append(pattern)
    return {"actual_yield_patterns": patterns,
            "trace_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "observed_source": starts[0]["expected_source"],
            "observed_source_sha256": starts[0]["expected_source_sha256"],
            "observation": "Actual padded PatternList arguments observed at every call to memmove_pattern_list; "
                           "read-only Python profiling adds timing overhead."}


def analyze(run_path, mode, baseline="historical"):
    require(baseline in ("historical", "abi-corrected"), "unsupported baseline kind")
    run = Path(run_path).resolve()
    require((run / "exit-code.txt").read_text().strip() == "0", "driver/outer timeout exit code is not 0")
    raw = (run / "stdout.log").read_bytes()
    text = ANSI.sub("", raw.decode("utf-8", errors="strict"))
    stderr = (run / "stderr.log").read_text(encoding="utf-8")
    require(not re.search(r"Unknown Exception|Traceback|\(retest\)", text + stderr),
            "exception or retest present; manual investigation is required")
    require(text.count("End Testing!") == 1, "incomplete/concatenated run")
    require(one_value(re.findall(r"^ThreadNum:\s*(\d+)\s*$", text, re.M), "ThreadNum") == 3,
            "worker thread count changed")
    kp_lines = re.findall(r"^kpNumArray:\s*([0-9 ]+)\s*$", text, re.M)
    require(len(kp_lines) == 1 and [int(item) for item in kp_lines[0].split()] == KPS,
            "dry-run key-point counts changed")
    schedules, errors = [], []
    for line in text.splitlines():
        match = TEST.match(line)
        if match:
            ordinal = int(match.group(1))
            require(ordinal == len(schedules) + 1, "schedule ordinal is not contiguous")
            schedule = ast.literal_eval(match.group(2))
            valid_schedule(schedule, mode)
            schedules.append(schedule)
        if re.match(r"^\s*\[Error Found\]:", line):
            require(bool(schedules), "error marker before any schedule")
            errors.append(len(schedules))
    total = one_value(re.findall(r"^Round\s+\d+\s+(\d+)\s*$", text, re.M), "total Round")
    error_count = one_value(re.findall(r"^Total Error Interleavings:\s*(\d+)\s*$", text, re.M), "error count")
    timeouts = one_value(re.findall(r"^Total Timeouts Interleavings:\s*(\d+)\s*$", text, re.M), "timeout count")
    require(total == len(schedules) and 0 < total <= 10000, "executed schedules/footer/budget disagree")
    require(len(set(json.dumps(value) for value in schedules)) == total, "duplicate schedules")
    require(error_count == len(errors) == len(set(errors)), "error markers/footer disagree")
    require(timeouts == 0, "target timeouts prevent pilot acceptance")
    artifacts = list((run / "work").glob("out_reorder_3_bad_*"))
    require(len(artifacts) == 1 and artifacts[0].is_dir(), "need exactly one untouched raw output directory")
    require(all((artifacts[0] / dirname).is_dir() for dirname in ("Errors", "Timeouts", "DiffResult")),
            "raw output is missing an Errors/Timeouts/DiffResult directory")
    saved = {}
    for path in sorted((artifacts[0] / "Errors").glob("*")):
        require(path.is_file(), "unexpected directory in Errors")
        match = ERROR_FILE.match(path.name)
        require(match is not None, "unexpected error type/name: " + path.name)
        ordinal = int(match.group(1))
        require(ordinal in errors and ordinal not in saved, "error file ordinal missing or duplicated")
        record = path.read_text(encoding="utf-8")
        lines = record.splitlines()
        require(bool(lines), "empty error file")
        pattern = ast.literal_eval(lines[0])
        require(pattern == yield_pattern(schedules[ordinal - 1]), "saved yield disagrees with schedule")
        require("assert" in "\n".join(lines[1:]).lower(), "missing assertion evidence")
        saved[ordinal] = pattern
    require(sorted(saved) == errors, "full raw error records were not preserved")
    for dirname in ("Timeouts", "DiffResult"):
        require(not any((artifacts[0] / dirname).glob("*")), dirname + " is not empty")
    if mode in ("reference", "parallel") and baseline == "historical":
        require(total == 27 and errors == EXPECTED_ERROR_ORDINALS,
                "Parallel regression differs from archived 27/6/first6 path")
    elif mode == "serial":
        flattened = [tuple(thread for period in value for thread in period) for value in schedules]
        expected = set(itertools.permutations((0, 0, 1, 1, 2)))
        require(len(flattened) == len(set(flattened)) and set(flattened) == expected,
                "Serial fixed [2,2,1] enumeration loses/repeats legal event orders")
        require(error_count > 0, "Serial did not detect the benchmark assertion")
    result = {"mode": mode, "total_schedules": total, "first_error": errors[0] if errors else None,
            "error_ordinals": errors, "error_interleavings": error_count, "timeouts": timeouts,
            "stdout_sha256": hashlib.sha256(raw).hexdigest(), "schedules": schedules,
            "derived_yield_patterns": [yield_pattern(value) for value in schedules],
            "actual_saved_error_yields": saved}
    result.update(actual_yield_trace(run, schedules))
    result["baseline_kind"] = baseline
    if mode in ("reference", "parallel"):
        result["historical_comparison"] = {
            "reference_only": {"first_error": 6, "total_schedules": 27,
                               "error_interleavings": 6, "error_ordinals": EXPECTED_ERROR_ORDINALS},
            "matches": total == 27 and errors == EXPECTED_ERROR_ORDINALS,
            "note": "A corrected ABI result is a separate measurement; historical agreement is not a filtering rule."}
    if baseline == "abi-corrected":
        metadata = json.loads((run / "adapter-metadata.json").read_text(encoding="utf-8"))
        require(metadata.get("status") == "COMPLETED" and metadata.get("exit_code") == 0,
                "ABI-corrected driver did not complete uncensored exploration")
        require(metadata.get("scheduler") == ("serial" if mode == "serial" else "parallel") and
                metadata.get("depth") == 3 and metadata.get("target_timeout_seconds") == 5,
                "ABI-corrected driver configuration differs from pilot")
        require(metadata.get("abi_proof", {}).get("status") == "PASS",
                "missing validated ABI proof in driver metadata")
        layout = metadata.get("abi_layout")
        layer_hash = metadata.get("abi_layer_sha256")
        require(isinstance(layout, dict) and isinstance(layer_hash, str) and
                re.match(r"^[0-9a-f]{64}$", layer_hash), "missing concrete common ABI layer identity")
        spec = importlib.util.spec_from_file_location("period_evidence_memory_abi", Path(__file__).with_name("period_shared_memory.py"))
        memory_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(memory_module)
        concrete_abi = memory_module.MemoryABI.from_layout(layout)
        require(layout == concrete_abi.layout and metadata["abi_proof"].get("abi_profile") == "runtime-dwarf"
                and metadata["abi_proof"].get("layout") == concrete_abi.layout,
                "driver metadata ABI is not bound to its measured runtime proof")
        if mode == "reference":
            require(metadata.get("role") == "abi-only-parallel-reference" and metadata.get("budget") == 10000,
                    "corrected reference must be labeled separately from unmodified historical driver")
        result["abi_layout"] = layout
        result["abi_layer_sha256"] = layer_hash
        result["driver_role"] = metadata.get("role", "unified-comparison")
    if mode != "reference":
        metadata = json.loads((run / "adapter-metadata.json").read_text(encoding="utf-8"))
        require(metadata.get("status") == "COMPLETED" and metadata.get("exit_code") == 0,
                "adapter did not report complete, uncensored exploration")
        require(metadata.get("scheduler") == mode and metadata.get("depth") == 3 and
                metadata.get("target_timeout_seconds") == 5, "adapter configuration differs from pilot")
        accounting = metadata.get("accounting", {})
        require(accounting.get("limit") == 10000 and accounting.get("executed") == total and
                accounting.get("completed") == total and accounting.get("in_flight") == 0 and
                accounting.get("retests") == 0 and accounting.get("retests_completed") == 0 and
                accounting.get("physical_launches") == total and accounting.get("budget_hit") is False,
                "adapter accounting does not reconcile with actual writes and stdout")
        require(metadata.get("upstream_statistics", {}).get("rounds") == total,
                "adapter's final rounds differs from executed schedules")
        result["adapter_accounting"] = accounting
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action")
    comparison = sub.add_parser("compare")
    comparison.add_argument("--reference-dir", required=True)
    comparison.add_argument("--candidate-dir", required=True)
    comparison.add_argument("--output", required=True)
    comparison.add_argument("--baseline", choices=("historical", "abi-corrected"), default="historical")
    inspection = sub.add_parser("analyze")
    inspection.add_argument("--run-dir", required=True)
    inspection.add_argument("--mode", choices=("reference", "parallel", "serial"), required=True)
    inspection.add_argument("--output", required=True)
    inspection.add_argument("--baseline", choices=("historical", "abi-corrected"), default="historical")
    args = parser.parse_args(argv)
    if not args.action:
        parser.error("choose compare or analyze")
    destination = Path(args.output)
    if destination.exists():
        parser.error("refusing to overwrite " + str(destination))
    result = {"schema": "cs340-period-pilot-evidence-v1", "status": "BLOCKED"}
    try:
        if args.action == "compare":
            reference = analyze(args.reference_dir, "reference", args.baseline)
            candidate = analyze(args.candidate_dir, "parallel", args.baseline)
            for field in ("schedules", "derived_yield_patterns", "actual_yield_patterns", "observed_source",
                          "observed_source_sha256", "error_ordinals", "actual_saved_error_yields",
                          "total_schedules", "error_interleavings", "timeouts"):
                require(reference[field] == candidate[field], "A/B mismatch in " + field)
            if args.baseline == "abi-corrected":
                for field in ("abi_layout", "abi_layer_sha256"):
                    require(reference[field] == candidate[field], "corrected A1/B common ABI mismatch in " + field)
                result["unmodified_historical_driver"] = "A0: audit only; not executed by this ABI-corrected comparison"
            result.update({"reference": reference, "candidate": candidate})
        else:
            result["run"] = analyze(args.run_dir, args.mode, args.baseline)
        result["status"] = "PASS"
    except Exception as exc:
        result["reason"] = str(exc)
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("{0}: {1}".format(result["status"], destination))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    sys.exit(main())
