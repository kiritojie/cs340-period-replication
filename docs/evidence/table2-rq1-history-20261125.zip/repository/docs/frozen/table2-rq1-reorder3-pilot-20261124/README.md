# Frozen validated reorder_3 pilot

This is a byte-preserved copy of the harness that passed the real A1/B/C pilot.
Original raw evidence remains at the paths in FREEZE.json; it is neither overwritten nor relabeled as formal repetitions.
A0 remains an ABI-unverified historical reference. Do not pool A0, adaptation or pilot data with new formal runs.
Parameterization occurs only in the working preflight, validators and experiment entry; the validated ABI, permission/cleanup and scheduler driver modules are protected by hashes.
