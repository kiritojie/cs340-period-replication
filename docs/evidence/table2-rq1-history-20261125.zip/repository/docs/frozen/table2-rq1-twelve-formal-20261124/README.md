# Frozen twelve accepted RQ1 formal rounds

The original reorder_3 and reorder_4 evidence is indexed by repository-relative hashes in FREEZE.json. The twelve-row table and four group summaries were recalculated by the unchanged report/acceptance functions. The incomplete reorder_5 export remains preserved outside this accepted-data freeze. Its recovery must pass its own full evidence and environment acceptance before inclusion.
