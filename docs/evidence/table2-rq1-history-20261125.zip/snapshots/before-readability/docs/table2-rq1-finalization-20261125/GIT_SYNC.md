# Table 2 — RQ1 安全同步顺序

本阶段没有 Commit、Push、合并、清理或删除历史实验。当前的 `.gitattributes`、README 和提交清单可供检查；请在完成最终审阅后手动执行下面的命令。

## 同步基线与合并原则

- 本地 `main` 起点为 `68c8329`。本地 `origin/main` 的 `47c71e5` 已过时；在线核验的远程 `main` 为 `5d1fd043b9daf3b94a5d81eb6ff787d7985b8adf`，之后仍可能更新。不能把本地显示的“落后 5 次提交”当成当前远程状态。
- README 的整理以在线版本为基础，保留组员 CPU Affinity Extension、李志杰对照表及贡献记录，再加入叶浩铭的 RQ1 成果。合并时保留双方必要段落、链接及个人贡献，不用整文件 `ours` 或 `theirs` 覆盖。
- `.gitattributes` 同时保留远程 `scripts/*.sh text eol=lf`、`scripts/*.py text eol=lf`，本地原始证据与 vendor 的 `-text` 规则，以及 CPU affinity 证据的精确字节保护。原始证据含已有 CRLF 和 LF，不对其批量转换换行符。
- 当前环境不能写入 `.git/FETCH_HEAD`，因此本次未完成 `git fetch`。下面的同步步骤需在有仓库写权限的本机终端执行。

## 提交范围

只使用本目录的 `staging-paths.txt` 明确纳入源代码、协议、必要配置、回归测试、冻结记录、报告、最终统计图表及唯一整理后的证据压缩包。文件数量、大小及 50 MB 检查以 [SUBMISSION.md](SUBMISSION.md) 为准。

原始和恢复会话目录、失败证据及重复历史副本仍保留在本地，但不通过 `git add .` 一并提交。压缩包保留原始文本证据，包括被一般忽略规则匹配的错误调度记录与 ConConfig；省略的编译产物和构建中间文件逐项记录身份与 SHA256。完整原始清单是在本地完整证据上审核的，不能宣称省略产物后的新 Clone 可无条件通过全部原始清单。

## 具体操作

在仓库根目录的 PowerShell 执行。先检查实际改动，再创建独立分支：

```powershell
Set-Location E:\cs340-period-replication
git status --short
git switch -c chore/table2-rq1-finalize-20261125
git add --pathspec-from-file=docs/table2-rq1-finalization-20261125/staging-paths.txt
git diff --cached --stat
git diff --cached --check
git diff --cached --name-only
git diff --cached -- .gitattributes .gitignore README.md
```

逐项核对暂存清单与 `SUBMISSION.md`；不要纳入未经审阅的核心实验代码改动、缓存、展开的原始会话、重复临时副本或编译产物。由于压缩包可能被一般 `*.zip` 规则忽略，整理后的 `.gitignore` 应有仅针对该证据包的精确例外；若 `git add` 提示仍被忽略，应先检查例外和文件路径，不要对整个目录使用强制添加。

确认暂存内容后再手动提交、更新远程引用并合并：

```powershell
git commit -m "Finalize Table 2 RQ1 reproduction with audited 24-round evidence"
git fetch origin
git merge origin/main
```

若出现冲突，打开冲突文件，按上述原则合并 `.gitattributes` 和 README；保留远程 CPU affinity、组员成果和本地 RQ1 内容。检查冲突解决结果后执行：

```powershell
git add .gitattributes README.md
git diff --cached --check
git diff --cached --stat
git merge --continue
```

只有确实处于合并冲突状态时才执行最后三步。若还有其他冲突，先逐个审阅解决，不能直接继续。

合并成功后，再审核最终差异并正常推送个人分支：

```powershell
git status --short
git log --oneline --decorate -8
git diff origin/main...HEAD --stat
git diff origin/main...HEAD -- .gitattributes .gitignore README.md
git push -u origin chore/table2-rq1-finalize-20261125
```

在 GitHub 创建指向 `main` 的 Pull Request，检查变更清单并由小组正常审阅合并。若 Push 因远程更新被拒绝，先 `git fetch origin`，再合并相关远程分支并重试普通 Push；不用 Force Push、`reset --hard` 或 discard changes。
