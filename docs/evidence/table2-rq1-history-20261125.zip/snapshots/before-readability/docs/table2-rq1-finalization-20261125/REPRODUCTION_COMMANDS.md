# Recorded commands and offline review

Finalization did not execute any experiment command below.

## Historical experiment entry points

The original recovery/continuation command was:
~~~bash
python3 -B /mnt/e/cs340-period-replication/orchestration/table2_rq1_batch.py --recover-from /mnt/e/cs340-period-replication/docs/results/table2-rq1-batch-20261124T164754Z-zphvi2gi
~~~
This starts unfinished experiments; it is a historical record, not a finalization
step. A new cohort, if separately authorized later, uses:
~~~bash
cd /mnt/e/cs340-period-replication
sudo -v
python3 -B orchestration/table2_rq1_batch.py --prepare
~~~
It requires the measured Linux/container environment, retained pinned image,
verified source/products/runtime, permissions and a fresh evidence location.
The fixed protocol is config/table2-rq1-protocol.json. Native commands, complete
argv, timestamps, exit codes and stderr are stored in the archived canonical
session. Official build commands/toolchain/output hashes are in its batch-build
stages; these steps were not repeated during finalization.

## Offline integrity check

With complete original local evidence, the existing read-only helper verifies
all original nested manifests:
~~~powershell
python -X utf8 -B -c "import sys; from pathlib import Path; sys.path.insert(0,'orchestration'); from rq1_integrity import verify_tree; print(verify_tree(Path('docs/results/table2-rq1-recovered-session-20261124T180224Z-210n7nbf'))); print(verify_tree(Path('docs/results/table2-rq1-batch-20261124T185640Z-re9h7z8a')))"
~~~
For the curated archive use included-member verification in SUBMISSION.md.
Omitted compiled/array copies prevent full original manifest closure after
curated extraction. The frozen scripts/table2_rq1_report.py is an offline report
writer; it never launches a target and requires a new output directory.
Its path/session checks assume the recorded repository layout and full evidence.
The curated archive does not claim that complete binary contract.
