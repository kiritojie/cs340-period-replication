# Suggested Table 2 RQ1 Submission

**Ready for review; no Commit or Push performed.**

Proposed new/changed files: **240 files, 15,492,369 bytes (15.492 MB / 14.775 MiB)**.
Unchanged tracked files covered by a source-directory pathspec are not counted as changes.

| Category | Files | Bytes |
| --- | ---: | ---: |
| Code, configuration and tests | 71 | 893,993 |
| Curated text-evidence ZIP | 1 | 12,752,967 |
| Final batch, statistics and charts | 65 | 340,694 |
| Final report and documentation | 19 | 221,271 |
| Freeze descriptors and review patches | 81 | 1,254,408 |
| README and Git rules | 3 | 29,036 |

Each proposed file and the entire proposed payload are below 50,000,000 bytes. No compiled executable, object, bitcode, cache or array intermediate is selected. Largest file: the curated evidence ZIP.

Exact file/size inventory: [submission-files.csv](submission-files.csv). Staging allowlist: [staging-paths.txt](staging-paths.txt). Use it instead of git add .

## Evidence package and preservation

Archive: docs/evidence/table2-rq1-evidence-20261125.zip

Size: **12,752,967 bytes**. SHA256: 8e0540ed36a3a9b2e5b38158fed42280c724aeb30ef4d2b57b7aa262b7c54fec.

The archive preserves 6,769 original text files (165,948,694 bytes before compression). 51 compiled/cache/array/lock artifacts are omitted, with exact path/size/SHA256 in [evidence-archive.json](evidence-archive.json) and PACKAGE_OMISSIONS.json inside the ZIP.

All original directories and failed records remain locally in place. Expanded sessions and duplicated historical/build copies are ignored for Git; only this curated ZIP has an archive exception. Raw out_*/Errors schedules and ConConfig records are included despite general Git ignore rules. Only canonical completed formal records enter statistics. Required source/ABI/pilot and failed export/setup records are included; redundant earlier sessions/preparation copies are local-only.

**Coverage:** the 59 original SHA manifests passed on complete local originals. Curated extraction omits artifacts referenced by some original manifests; it guarantees byte integrity of included files, not full original binary-manifest closure in a new clone. No omitted binary is silently treated as verified in the curated package.

## Verify without extraction or target execution

From the repository root in PowerShell:

~~~powershell
@'
from pathlib import Path
import hashlib, zipfile
p = Path("docs/evidence/table2-rq1-evidence-20261125.zip")
expected = "8e0540ed36a3a9b2e5b38158fed42280c724aeb30ef4d2b57b7aa262b7c54fec"
assert hashlib.sha256(p.read_bytes()).hexdigest() == expected
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None
    for line in z.read("PACKAGE_SHA256SUMS").decode("utf-8").splitlines():
        digest, name = line.split("  ", 1)
        assert hashlib.sha256(z.read(name)).hexdigest() == digest, name
print("PASS: archive and all included original files")
'@ | python -X utf8 -B -
~~~

Extraction is optional; use a separate review directory to avoid overwriting existing evidence. Read PACKAGE_README.md and PACKAGE_OMISSIONS.json before checking original nested manifests.

## Report, commands and validation

- [FINAL_REPORT.md](FINAL_REPORT.md): English Reproduction Setup, Results and Critical Analysis; eight-group table, claim verdict and personal contribution.
- [paper-vs-ours.csv](paper-vs-ours.csv): exact means, sample SD, n, deltas and censoring.
- [audit-details.json](audit-details.json): 24-round raw audit; 59 manifests / 16607 entries / 6293 distinct referenced files.
- [charts-audit.json](charts-audit.json): five plots, 40 data rows, 120 statistics and eight rates.
- [source-identities.json](source-identities.json) and [final-checks.json](final-checks.json): current source snapshot, 64 frozen harness hashes unchanged.
- [REPRODUCTION_COMMANDS.md](REPRODUCTION_COMMANDS.md): recorded commands and offline checks. No new experiment is required.
- Existing tests and historical execution records are retained. This documentation/archive finalization did not rerun target or Linux execution tests.

Only editable final documentation and Git rules were normalized to LF. Evidence and pinned vendor bytes retain original CRLF/LF through -text or ZIP storage. Executable scripts, orchestration and tests retain LF; vendor exact-byte rules remain effective. No broad git add --renormalize was used.

## Commit and Git integration

Suggested Commit Message:

~~~text
Finalize Table 2 RQ1 reproduction with audited 24-round evidence
~~~

Follow [GIT_SYNC.md](GIT_SYNC.md). Local HEAD is 68c8329; cached origin/main 47c71e5 is stale. Live API verified main 5d1fd043 on 25 November 2026. Shell fetch could not write .git/FETCH_HEAD, so no Git merge is claimed. README is a reviewed combined candidate preserving current remote CPU Affinity and Li Zhijie credits; remote-only link targets arrive with actual integration. .gitattributes retains remote LF rules plus local evidence/vendor rules. Re-fetch before a normal merge and ordinary branch Push/PR.
