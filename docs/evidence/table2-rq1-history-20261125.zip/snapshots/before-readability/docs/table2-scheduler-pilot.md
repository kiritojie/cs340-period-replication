# Table 2 / RQ1: scheduler adaptation and reorder_3 pilot

Date: 24 November 2026 (UTC+8).

**Overall result: BLOCKED BEFORE BENCHMARK.** Driver adaptation and offline
validation are available for review. No A, B or C benchmark run occurred.
There is no measured Serial result and no completed live Parallel regression.
The four-program formal experiment is **not ready to start**.

## 1. Live environment and stopping decision

The host probe in `results/table2-scheduler-pilot-20261124/host-live-probe/`
preserves the exact command arrays, return codes, decoded output and original
stdout/stderr bytes. The successful local Python/file operations do not imply
access to the user's WSL distribution or experiment container.

| Check | Actual status |
| --- | --- |
| `wsl.exe --list --verbose` | BLOCKED: `Wsl/E_ACCESSDENIED`, return code 4294967295 |
| Docker / Podman CLI | Not found in the current session's PATH or checked standard installation locations |
| Current container and scheduling permissions | NOT VERIFIED |
| Actual PERIOD container HEAD | NOT VERIFIED |
| Current `reorder_3_bad` SHA-256 | NOT VERIFIED |
| Linked runtime / `DBDSFunction.o` layout | NOT VERIFIED |
| A: original Parallel | NOT RUN |
| B: adapted Parallel | NOT RUN |
| C: adapted Serial | NOT RUN |

The precise reason the WSL access is denied cannot be determined from the
returned error. This report does not claim WSL is uninstalled, Docker is absent
from the user's machine, or the archived container has failed its checks.

The early `BLOCKED.txt` is an initial failure snapshot. Its statement that tests
were then unverified is superseded by the offline verification records below.
A temporary execution-transport failure during development was resolved by
using the supported PowerShell command entry point. WSL remains inaccessible.

No benchmark, compiler, linker, container restart, IPC deletion, Commit or Push
was used to work around the environment failure. Historical evidence was not
overwritten. The original binary was neither rebuilt nor replaced.

## 2. Files and provenance

| File | Purpose |
| --- | --- |
| `scripts/run_scheduler_comparison.py` | Import-safe unified orchestration adapter |
| `scripts/table2_scheduler_pilot.sh` | Fail-closed Linux pilot and evidence collection |
| `scripts/table2_scheduler_preflight.py` | Executable/object DWARF and identity checks |
| `scripts/table2_scheduler_evidence.py` | Log, actual yield-write and A/B regression checks |
| `scripts/trace_period_driver.py` | Read-only Python profiling of actual yield-matrix writes |
| `scripts/vendor/period_b6f72a7/` | Unmodified fixed upstream source snapshots, manifest and MIT license |
| `tests/` | Offline generator, orchestration, ABI-proof and observer tests |
| `docs/patches/table2-scheduler-*.patch` | Full generated-source differences for both modes |
| `docs/results/table2-scheduler-pilot-20261124/` | This stage's checks and blocking evidence |
| `.gitattributes` | Preserve original upstream and checksummed evidence bytes |

The snapshot manifest fixes commit
`b6f72a7b06d01ffa7114b640312873ec2578a5ea`. Original DBDS Git blob IDs were
checked against official repository metadata. The adapter checks source bytes
against both SHA-256 and Git blob identity before imports or source adaptation.
It explicitly loads the official local `sched.py`, avoiding the standard-library
module with the same name.

The driver derives its executable source in memory from the verified
`run_PDS.py`. Exact replacement anchors must match. No upstream checkout file
is edited. The complete patches are review artifacts for that derived source;
they also refer to helper functions defined in the adapter, so they are not
standalone replacement drivers and should not be applied to the original
container checkout. Patch and derived-source hashes are recorded separately.

## 3. Adaptation decisions

| Area | Decision and possible effect |
| --- | --- |
| Generator calls | All four construction sites use the selected official class; no core class is modified |
| Parallel | Original `SBPMESched` order and fixed-prefix constructor are preserved |
| Serial | Official `SBPSched`; no emulation by reducing the benchmark thread count |
| Period window | Parallel: 2 through d+1; Serial: N through d+N-1 |
| Logical depth | Parallel p-1; Serial p-N+1, used only for depth-dependent control/printing |
| Runtime period index | Remains the actual p-1 written to shared memory |
| First-depth branches | All four former `iterPeriod == 2` decisions become mode-dependent first-depth decisions |
| Deep pruning | Uses logical depth, so Serial p=5 at d=3 is not mistaken for a depth-4 job |
| Feedback / errors | Original feedback and assertion/ASan classification retained; unexpected exceptions stop the run |
| Impossible slices | Only the explicit no-schedule condition is handled as an empty generator |
| Budget | Checked before another logical target launch, with a controlled exit outside every period/stage/prefix loop |
| Timeout cleanup | Adapted target process groups are killed/reaped on timeout or interruption; these are documented orchestration changes |

### Prefix policy and its limitation

The public Serial constructor does not implement the Parallel
`fix_prefix=True` interface. Simply passing that keyword would fail; merely
dropping it would not ensure an equivalent fixed-prefix constraint.

For Serial feedback jobs, the adapter enumerates the unchanged official Serial
generator and selects the complete prefix-compatible subset: earlier completed
periods match exactly, and the final prefix period is a nonempty beginning of
the corresponding candidate period. This policy is fixed before any real
measurement and is tested against an independent small-input oracle. It is not
a filter for achieving the paper's numerical results.

This is a disclosed implementation difference from the old Serial driver's
prefix constructor. Rejected generated candidates add Python work, so generated
candidate counts and wall time must be reported separately from executed
schedules. No claim is made that this reconstruction is byte-for-byte identical
to the authors' original RQ1 experiment harness. If a live prefix failure occurs,
the run stops; it must not be repaired by silently dropping jobs.

### Accounting definitions

- `generated`: candidates produced by the official generator, including rejected
  Serial prefix candidates; an additional generated candidate may expose that
  the execution budget has been exhausted.
- `executed`: distinct logical exploration schedules whose target Popen succeeds.
- `completed`: those logical launches that have returned or been reaped, including
  timeout cleanup; timeout/error categories remain separately recorded.
- `retests` / `retests_completed`: physical reruns of an existing logical schedule
  when the upstream feedback discovers a larger thread/key-point buffer need.
- `physical_launches`: executed + retests. Dry run and default-schedule calibration
  are excluded from the formal exploration budget.

The pilot analyzer stops for any retest, timeout, duplicate, malformed output or
unaccounted error record. These outcomes are preserved as failures, not excluded
and silently rerun. Budget exhaustion is not repaired by subtracting one from
the original footer.

## 4. Runtime ABI gate

The source snapshot has a real discrepancy: `run_PDS.py` uses 1990 entries while
`DBDSFunction.cpp` declares 3964 entries for each of kp/kpLoc/kpOrder. Both use
16-bit array elements. The old Serial driver instead uses 32-bit arrays.
No constants or compiled products were changed to make this pass.

The preflight requires DWARF from the existing executable and
`tool/staticAnalysis/DBDS-INSTRU/DBDSFunction.o`. It follows the defined runtime
global `si` in the `DBDSFunction.cpp` compilation unit to its actual structure
type. A same-named unused structure is not sufficient evidence.

The current driver expects the following layout:

| Field | Byte offset | Unsigned element bytes | Dimensions |
| --- | ---: | ---: | --- |
| time | 0 | 8 | scalar |
| N | 8 | 4 | scalar |
| M | 12 | 4 | scalar |
| TestedBounds | 16 | 4 | scalar |
| kpNumArray | 20 | 2 | 100 |
| kp | 220 | 2 | 1990 |
| kpLoc | 4200 | 2 | 1990 |
| kpOrder | 8180 | 2 | 1990 |

Expected structure size is 12160 bytes, including alignment padding. An observed
3964-entry layout, missing/stripped DWARF, wrong field type or offset, changed
binary, unproven object, wrong source version or missing permission blocks all
target runs. The adapted driver rechecks the proof against the selected current
files; a JSON status of PASS alone is insufficient.

Matching object/executable layouts establishes compatibility of those layouts,
not original build/link provenance. Source HEAD and file hashes alone cannot
prove which object was originally linked. No actual ABI observation was possible
in this session.

## 5. Offline verification

The final `offline-verification.json` and `unittest.stdout.log` /
`unittest.stderr.log` under this stage's evidence directory are authoritative for
test count, command, return code and timing. Tests run on host Python 3.12.4.
All synthetic data and fake target-I/O tests are explicitly offline tests.

Coverage includes independent Serial event-order and Parallel period-assignment
oracles; exact key-point multiplicities; adjacent periods; per-thread event
order; yield decode/encode; complete prefix subsets; original Parallel order;
correct depth versus true period index; normal footer handling; and real adapted
multi-stage control flow with fake target I/O at small execution budgets.

Synthetic DWARF tests cover 1990 versus 3964 layouts, unsigned widths, offsets,
the actual runtime `si` type, missing/conflicting compilation units and proof
revalidation. These passing tests do not mean the live runtime ABI passed.
The original and adapted benchmark paths remain unexecuted.

Final recorded result: **51 offline tests passed**, exit code 0. The earlier
saved `offline-attempt-01/` has 41 tests and one fixture error: a synthetic valid
proof did not mock the newly added Linux host gate. That fixture was corrected
without weakening the product gate, and explicit non-Linux / wrong-ctypes
rejection tests were added. Both the failure and final success logs are retained.

All four product Python files pass Python 3.6 grammar parsing, but their tests
ran on Python 3.12.4, not the container's Python 3.6.9. Linux `bash -n` and shell
execution are **NOT VERIFIED**: no independent Bash is available and WSL is
blocked. This limitation is separate from the passing Python tests.

The 14 upstream snapshot files still match their original SHA-256 and Git blob
digests. The only modified pre-existing tracked file is `.gitattributes`;
historical results and the existing README are unchanged.

## 6. Live regression and paper comparison

The pilot requires a single current environment and frozen input binary:

`ed2d13809b87a00eaaba76ac0f1faf4871a489a0960993e5963dc89b4bb13db9`

Expected ConConfig SHA-256:

`0ed49729a85b862b9a918c62f3826f3c56b89ec825ae3fe35a28f21f253d7d4d`

The wrapper allocates unique working directories and executes A then B. Only
after the complete A/B regression passes may it start C. Both A and B use the
same read-only observer to preserve every actual padded PatternList written by
`memmove_pattern_list`, not only reconstructed yields or the six error samples.
Observation adds timing overhead; wall-clock results are diagnostic only.

Common settings: depth 3, budget 10000, target timeout 5 seconds, external
timeout 600 seconds and TERM-to-KILL grace 20 seconds. No concurrent PERIOD
drivers are allowed in the IPC namespace. The script checks attached IPC users,
active drivers, array segment size and CPU affinity, and never performs ipcrm.

| Run | Actual result | Reference only: first / total / buggy / timeout |
| --- | --- | --- |
| A original Parallel | NOT RUN - environment blocked | 6 / 27 / 6 / 0 |
| B adapted Parallel | NOT RUN - A/B gate not reached | 6 / 27 / 6 / 0 |
| C adapted Serial | NOT RUN - A/B gate not reached | paper: 10 / 30 / 10 / not specified |

Parallel reference error IDs are 6, 7, 19, 20, 24, 25. Live A/B acceptance requires
identical ordered schedules, all actual observed yield matrices, error IDs,
counts, complete raw error records and zero timeouts. The full historical
experiment is a reference, not a substitute for current A/B evidence.

Serial measurements must be preserved even when different from the paper.
The pilot's legal fixed-slice completeness check is independent of the paper's
error count; first/error-count differences must be reported, not tuned away.

Paper sources: [PERIOD PDF, Table 2, PDF page 9](https://wcventure.github.io/pdf/ICSE2022_PERIOD.pdf#page=9)
and configuration/RQ1 on PDF page 8; scheduler definition in section 3.2.

## 7. Review and resumption

Current recommendation: **do not start reorder_4/5/10 or ten-round batches**.
This stage has no live pilot data supporting that decision.

After the WSL/container access problem is resolved, make these new scripts and
tests available in the existing container, retaining their relative directory
structure. First collect preflight evidence:

```bash
bash scripts/table2_scheduler_pilot.sh \
  --upstream /workdir/PERIOD --output-root /lab/evidence
```

Only a successful environment/ABI gate and human review justify the already
scoped reorder_3 pilot:

```bash
bash scripts/table2_scheduler_pilot.sh --execute \
  --upstream /workdir/PERIOD --output-root /lab/evidence
```

Each invocation uses a fresh evidence directory. The script contains no path
for a reorder_4/5/10 batch. The current status remains BLOCKED until actual new
environment and A/B/C records demonstrate otherwise.

## 8. Initial adaptation Git review snapshot (before rootful handoff)

Actual `git diff --stat` output at completion:

```text
 .gitattributes | 14 ++++++++++++++
 1 file changed, 14 insertions(+)
```

There are also **45 new untracked files**: implementation, tests, unchanged
upstream snapshots, full adaptation patches, this report and evidence. Git's
ordinary diff stat omits untracked files; no staging was performed merely to
make them appear in the stat. The expanded `git-status.txt` in the evidence
directory lists them for review. Its `implemented-files.sha256` fixes all five
new implementation scripts and four test files. `SHA256SUMS` verifies the
16 saved environment, test, provenance and review evidence files.

No original core algorithm, runtime, historical result, existing README or
binary was changed. No Commit or Push was performed. Human review is pending;
the live pre-experiment remains blocked.

## 9. Rootful Podman recovery handoff (24 November, follow-up)

The user located the existing environment in a separate Ubuntu terminal:
Ubuntu-22.04 / WSL2, rootful Podman 3.4.4, image ID
`dfd654d5ebf18787ebff0b8cc35c61c6eda4d49852a93bb784fbe2e82727299a`.
The original container is `period-table2-reorder3` / `8661e83e39a4`, reported
Exited(0); `period-table2-reorder3-v2` / `3ede0d6a8445` is reported Created.
These details are user-confirmed, not observations made by Codex.

Codex retried `wsl.exe -d Ubuntu-22.04 --exec /bin/true` and again received
`Wsl/E_ACCESSDENIED` (4294967295). A request for elevated execution was rejected
before execution by the current platform approval policy; it could not be
submitted as a user approval prompt. Raw output and the rejection explanation
are preserved under `results/table2-rootful-resume-preparation-20261124/`.
No live Podman inspection, restart, ABI check, Linux/Bash test or A/B/C run has
therefore been performed by Codex in this follow-up either.

### Executable Ubuntu handoff

New `scripts/resume_table2_podman.py` performs the complete gated workflow from
the user's Ubuntu terminal. The initial handoff used `sudo -n podman` throughout
(the root-direct correction is documented in section 11); rootless Podman
and Docker are not fallbacks. It never pulls/loads/builds an image, creates or
removes a container, deletes IPC, changes affinity, or compiles a benchmark.

To run the already-authorized reorder_3 workflow in Ubuntu:

```bash
cd /mnt/e/cs340-period-replication
sudo -v
python3 scripts/resume_table2_podman.py --execute
```

Without `--execute`, the same command only inspects, copies existing products to
new evidence directories and checks available host DWARF; it does not start or
exec into containers. Each invocation uses a new unique directory under
`docs/results/table2-rootful-resume-*`. The historical lab directory is read
only, and `PERIOD-amd64.oci.tar` is neither reloaded nor replaced.

The workflow is:

1. Archive complete JSON inspection of both named containers and the existing
   image, rootful engine information and bounded named historical records.
2. Select the original container only after matching its name, ID and image.
   The Created v2 is never silently substituted.
3. Copy the existing binary, ConConfig and DBDSFunction.o even while stopped.
   Check binary/config hashes; if host GNU readelf is available, inspect actual
   object/executable layout before starting anything.
4. Only for a proven idle startup argv, start the existing container with its
   existing configuration. Unknown shell `-c` commands or experiment entrypoints
   stop the script. Restarting preserves the writable layer and launch config;
   transient process/IPC state is newly observed and recorded.
5. Compare original and resumed launch configurations, including permissions,
   mounts, CPU/cgroup and IPC settings. Observe current execution affinity and
   pass that same explicit expected CPU list to every arm.
6. Copy only the new harness/tests into a fresh `/tmp/cs340-rq1-resume-*` tree;
   leave `/workdir/PERIOD` and old outputs untouched. Run Linux `bash -n`, then
   the existing full tests/provenance/DWARF/deadline/IPC gates.
7. Execute A then B; C remains inaccessible until actual schedule/yield/error
   regression passes. Every target run is still depth 3, budget 10000, target
   timeout 5 seconds and outer timeout 600 seconds.
8. Export complete native evidence even on failure, recheck original product
   hashes, and generate `resume-summary.json`, `RESUME_REPORT.md`, command logs
   and `SHA256SUMS`. The existing container and all evidence remain in place.

If sudo credentials expire or an export fails, evidence remains in the recorded
container work root; the bridge reports BLOCKED rather than claiming a complete
export. Root-owned exported files are chowned only within the newly created host
evidence directory. Historical files and directories are never chowned.

### Affinity correction and remaining gates

The previous `0-7` gate described the second host. The original host's early
record describes `0-31`, while historical per-run masks were never verified.
`table2_scheduler_pilot.sh` now accepts `--expected-cpus`, implemented by the new
strict `table2_scheduler_affinity.py`; the old default remains `0-7` for old
calls. The bridge explicitly supplies its current original-container observation
and records its source. It does not call taskset or modify the actual mask and
does not retroactively certify historical per-run affinity.

Both original-host and cross-host build manifests contain the same binary
`ed2d1380...13db9` and ConConfig `0ed49729...d7d4d`; those identity gates were not
weakened. The 1990/3964 shared-memory discrepancy is also not waived. A mismatch,
missing object, missing DWARF or unresolved permissions still stops the pilot
without recompiling or modifying the core runtime.

Follow-up local verification: **81 offline tests passed** (51 previous checks,
13 affinity tests and 17 mocked rootful-recovery checks). These include failure
paths in which final product rechecks must override an earlier success status.
No mock/synthetic result is a real Podman/ABI/Benchmark observation. Actual Linux
syntax/tests and A/B/C results remain pending the user's terminal execution.

The derived scheduling source and its patches did not change in this follow-up;
only environment recovery, explicit affinity control, tests and documentation
were added. Formal batch readiness remains **NOT ESTABLISHED**.

Current follow-up Git review: `git diff --stat` reports `.gitattributes` with
19 insertions (ordinary diff stat excludes the new untracked implementation and
evidence files). Complete current status and the 81-test run are saved in the
follow-up preparation evidence directory. The original 51-test evidence and its
checksums were retained unchanged as an earlier-stage record.

Podman 3.4.4 primary documentation used for the handoff:
[cp supports stopped containers](https://docs.podman.io/en/v3.4.4/markdown/podman-cp.1.html),
[exec options](https://docs.podman.io/en/v3.4.4/markdown/podman-exec.1.html), and
[start preserves creation-time terminal settings](https://docs.podman.io/en/v3.4.4/markdown/podman-start.1.html).

## 10. ABI repair after the actual stopped-container inspection

The user's new failure evidence confirms the existing binary has a 3964-entry,
24008-byte Sched_Info, while the earlier preflight expected the legacy 1990
layout. The binary hash is unchanged. No target was started by that failed run.
The actual historical Python driver still needs extraction before its ABI and
file hash can be asserted; it is not inferred solely from the pinned source.

See `docs/table2-abi-compatibility.md` for the complete evidence audit, conditional
historical-impact analysis, common compatibility layer, new tests and source
patches. The current execution order is **A0 audit only -> A1 ABI-corrected
Parallel reference -> B unified Parallel regression -> C unified Serial**.
An ABI-corrected result must not be represented as an unchanged original-driver
result. A1/B agreement, not forced agreement with historical paper counts, gates C.

The updated Ubuntu commands are:

```bash
cd /mnt/e/cs340-period-replication
sudo -v
python3 scripts/resume_table2_podman.py --extract-only
# Full gated pre-experiment, after/repeating source extraction:
python3 scripts/resume_table2_podman.py --execute
```

The new runtime-dwarf proof does not skip ABI inspection: it validates the actual
binary/object layout and binds the exact ABI layer and both execution entry
points. The old v1/1990 proof remains for earlier test/record compatibility and
cannot authorize a corrected runtime-dwarf execution. Historical evidence and
the earlier source patches are preserved. The actual A1/B/C experiment and the
formal-batch decision remain pending; no formal four-program experiment started.

## 11. Root-direct permission correction after the 22:39 resume failure

The complete failure evidence is preserved at
`docs/results/table2-rootful-resume-20261124T223950-9_010480/`.
The native wrapper returned 2 after `sudo-probe`, before the deadline probe or
any A1/B/C launch. Its ABI proof is PASS and its Linux test log records
**141 tests, all passing**. The actual process status recorded inside the
container has real/effective/saved/filesystem UID and GID all zero;
CapInh/CapPrm/CapEff/CapBnd/CapAmb are all `0000000000800000` (SYS_NICE only),
`NoNewPrivs: 1`, and `Seccomp: 2`. Thus effective root was established by live
evidence, rather than inferred from the host prompt or container configuration.

The sudo error `PERM_SUDOERS: setresuid(-1, 1, -1): Operation not permitted`
is consistent with the missing SETUID capability: sudo still initializes its
policy plugin and attempts a credential transition when invoked by root.
The root process can control its same-UID children directly, but this does not
establish SCHED_DEADLINE or timeout/descendant cleanup success. Those operations
remain independent required live gates.

| Call site | Permission handling shared by A1/B/C |
| --- | --- |
| Official dry-run/default/target `sudo` prefix | Remove only the recognized sudo argv prefix under effective root; transfer leading environment assignments to the child environment and retain target argv/process-group handling |
| Official `sudo kill` / cleanup fallback | Use direct same-UID process/group signals as effective root; nonroot escalation uses noninteractive sudo |
| Pilot permission preflight | Record actual credentials/capabilities and run real process-control and scheduler probes; no sudo plugin probe under root |
| Host rootful Podman bridge | Effective root executes podman directly; nonroot retains sudo -n; root skips unnecessary ownership normalization |

The checked-in official snapshot, source checkout, binary, DBDSFunction.o,
runtime and verified ABI compatibility layer are unchanged. A1 remains the
Parallel reference with the existing ABI correction and the same documented
permission orchestration applied to B and C; its label does not imply byte-for-byte
unchanged official process launch commands. Scheduler generation, feedback,
classification and statistics are outside this permission correction.

`scripts/table2_scheduler_permissions.py` produces `permission-proof.json`
using schema `cs340-period-permissions-v1`. A PASS requires the unchanged
historical boundary (root, SYS_NICE only, no-new-privileges) and actual Linux
execution of TERM handling, timeout escalation to KILL, process-group descendant
cleanup, and SCHED_DEADLINE syscall success with kernel readback and restoration.
Any missing/failed probe returns BLOCKED. Both driver entry points receive the
same proof, and each arm has fresh before/after permission validation. The host
bridge also requires the exported permission proof before reporting PILOT_PASSED.
Removing sudo is therefore a launch compatibility repair, not permission acceptance.

All official child launches, including dry run and preparation, have their own
process group. The common supervisor adopts and reaps orphan descendants as a
temporary Linux child subreaper, then restores its previous setting. A TERM
received while Popen is starting a child is deferred until that child is
registered for cleanup; no signal mask is inherited by the target. The live
outer-watchdog probe exercises this same supervisor and verifies descendant
reaping and restoration. A1 retains the original timeout classification; B/C
retain their existing bounded timeout cleanup, with the same root permission
policy in both paths. Any target timeout still fails pilot acceptance.

The bridge rejects privileged containers, extra/absent capabilities, removal
of cap-drop=ALL or no-new-privileges, and nonroot execution in the selected
historical container. It still compares the complete original/current launch
configuration and rechecks all original source/product hashes. Each invocation
creates new evidence; no historical ownership, source or result file is changed.

From the **Ubuntu root terminal**, run:

```bash
cd /mnt/e/cs340-period-replication
python3 scripts/resume_table2_podman.py --execute
```

The command runs the mandatory live gates before the already authorized
reorder_3 A1/B/C pilot. A1/B regression must pass before C. There is no formal
batch, container capability change, sudoers change, image build/download,
Commit or Push. This repair is not a claim that the new live permission probes
have passed: this Windows session cannot enter WSL (`Wsl/E_ACCESSDENIED`), so
the next Ubuntu invocation must supply that evidence and may still fail closed.
