# Table 2 / RQ1: runtime ABI compatibility repair

> Final status update, 25 November 2026: the actual-source extraction, matching
> binary/object layout proof, all four A1/B regressions and 24 formal rounds are
> now complete and audited. See the [final report](table2-rq1-finalization-20261125/FINAL_REPORT.md).
> The preparation record below is preserved as written; its pending/conditional
> execution statements describe that earlier stage, rather than current status.

24 November 2026 (UTC+8). This is an ABI/interface adaptation, not a modification
of the official scheduling generators, runtime, existing object or benchmark.

## Evidence and present execution status

Input evidence: `docs/results/table2-rootful-resume-20261124T220134-l76oqi5n`.
All **72 SHA256SUMS entries** were verified, and all **65 text records** were
read. Re-parsing the full original `11-host-dwarf-binary.stdout.log` reproduces
`binary-observed-layout.json` exactly. The failed command stopped before any
container restart, native Bash test or target run.

The unchanged binary SHA-256 is
`ed2d13809b87a00eaaba76ac0f1faf4871a489a0960993e5963dc89b4bb13db9`.
The copied existing runtime object SHA-256 is
`ade32aae2113a59e4ff3382d73b17b953fe3a2bd439a2d27310d9f4f645f2004`.
The old inventory also records that object identity. Its actual DWARF still has
to be checked against the binary in the next live gate; the previous resume
stopped at the binary and did not collect an object DWARF dump.

Codex still receives `Wsl/E_ACCESSDENIED`. The actual historical
`/workdir/PERIOD/tool/DBDS/run_PDS.py` has **not yet been extracted**, so its
current bytes, hash, capacities and offsets are **NOT VERIFIED** here. The
pinned GitHub/vendor file is evidence about the pinned file only, not proof of
which bytes were used for a historical run. The extraction workflow below closes
that gap without starting a stopped container.

Even after extraction, the file is the currently preserved historical-container
copy. Without an archived per-run driver hash it cannot retroactively establish
the exact driver bytes at every historical invocation.

The original inspect confirms a restricted rootful container: not privileged,
capabilities dropped except SYS_NICE, no-new-privileges, private IPC/PID, network
none, and the historical directory mounted at `/evidence`. These settings are
retained; no new privileged container or replacement image is introduced.

## Observed binary ABI

| Field | Unsigned type | Offset | Extent |
| --- | --- | ---: | --- |
| time | uint64 | 0 | scalar |
| N | uint32 | 8 | scalar |
| M | uint32 | 12 | scalar |
| TestedBounds | uint32 | 16 | scalar |
| kpNumArray | uint16 | 20 | 100 |
| kp | uint16 | 220 | 3964 |
| kpLoc | uint16 | 8148 | 3964 |
| kpOrder | uint16 | 16076 | 3964 |

The last field ends at byte 24004, but the complete structure is **24008 bytes**
because of four bytes of tail alignment padding. Merely changing 1990 to 3964
in the old allocation expression would request 24004 bytes and would not express
the complete observed structure contract.

## Possible impact on historical results

The following is conditional until the actual historical driver is extracted.
The pinned driver uses 1990 uint16 entries and an allocation expression of
12160 bytes. If the actual historical driver matches that file, the mismatch is:

| Access | 1990-layout offset | Observed runtime offset | Consequence |
| --- | ---: | ---: | --- |
| time/N/M/TestedBounds | 0/8/12/16 | 0/8/12/16 | Header accesses coincide |
| kpNumArray | 20 | 20 | Thread key-point counts coincide |
| kp yield matrix | 220 | 220 | A small padded matrix can still reach the correct input bytes |
| kpLoc feedback | 4200 | 8148 | Starts at runtime kp[1990], not runtime kpLoc[0] |
| kpOrder feedback | 8180 | 16076 | Starts at runtime kpLoc[16], not runtime kpOrder[0] |

The old kpLoc copy would span 1974 elements of the yield-array tail followed by
16 actual location elements. The old kpOrder copy would instead read actual
location elements 16 through 2005. Coverage hashes and feedback could therefore
use incorrect data even when the target receives the intended small yield matrix.

In particular, actual assertion failures and the recorded 27/6/first6 counts are
not automatically imaginary or all invalid: the header, key-point counts and
small yield writes can still work. Conversely, matching those numbers does not
validate coverage feedback or the full exploration mechanism. Historical data
must remain labeled with its actual driver/ABI provenance and must not be merged
with repaired-ABI results. The repair must be evaluated through fresh paired
runs, not by rewriting historical counters or choosing filters to obtain 27 or 30.

If extraction shows a different historical driver, its actual expressions and
hashes must be assessed instead. An unknown source variation stops live execution
until its differences are reviewed; source pinning is not silently relaxed.

## Common compatibility implementation

| New or updated file | Change |
| --- | --- |
| scripts/period_shared_memory.py | New common checked ABI layer |
| scripts/run_abi_parallel_reference.py | New A1 ABI-only reference entry |
| scripts/run_scheduler_comparison.py | B/C ABI adaptation and v2 proof binding |
| scripts/table2_scheduler_preflight.py | Actual-source AST audit and v2 runtime proof |
| scripts/table2_scheduler_evidence.py | Corrected baseline distinction and common-ABI regression |
| scripts/resume_table2_podman.py | Stopped-container source extraction and measured layout handling |
| scripts/table2_scheduler_pilot.sh | A0 audit, A1/B/C sequencing and dynamic IPC size gate |
| tests/test_period_shared_memory.py, test_abi_driver.py | Buffer and adapted IPC tests |
| tests/test_table2_abi_proof_v2.py | Proof and source/entry binding tests |
| tests/test_abi_evidence.py, test_abi_resume.py | Baseline identity and extraction tests |
| tests/fixtures/period_runtime_3964_layout.json | Exact copy of the observed binary layout |
| .gitattributes | Preserve fixture/evidence bytes and LF scripts |

New `scripts/period_shared_memory.py` constructs a ctypes structure from the
observed DWARF layout and validates all eight names, unsigned widths, dimensions,
ordering, field offsets, array capacities and complete structure size. The
three point arrays must have identical capacity. No hard-coded offset arithmetic
in the derived driver remains responsible for IPC access.

The compatibility layer provides:

- Exact-size SysV allocation/attachment with checked native signatures and
  return values; existing attached or wrongly sized segments block execution.
- Bounded scalar and array reads/writes, unsigned value checks, N*M checks and
  receiving-buffer checks before feedback is used.
- Rectangular yield-matrix validation; only the kp field is written, with the
  unused kp tail cleared. time/N/M and feedback fields are not erased.
- No implicit clearing of an existing segment on attachment. The dry-run
  calibration header is preserved. The unmodified runtime remains responsible
  for initializing its key-point count/location/order fields on each launch.
- Fatal IPC exceptions that cannot be swallowed by the old driver's generic
  Exception handler. No native memory failure is converted into a passing run.

The ABI-only source transformation replaces all three old IPC helper functions,
all eleven scalar-write expressions, all four receiving ctypes arrays, capacity
constants/guards and actual feedback read paths. An AST check rejects leftover
direct memmove/memset/shmget/shmat calls in the derived orchestration. The real
period index remains p-1; the logical-depth mapping is unchanged by this repair.

The generic layer can describe legacy test layouts, but actual corrected entry
points require a v2 `runtime-dwarf` proof for this selected binary's
100-thread/3964-point/24008-byte layout. The legacy v1 validator remains only for
compatibility with earlier tests and records; it does not authorize the new
corrected entry points.

## Baselines and comparison order

| Label | Entry | Meaning |
| --- | --- | --- |
| A0 | Actual old run_PDS.py snapshot | Historical raw baseline; audit only, no incompatible execution |
| A1 | run_abi_parallel_reference.py | Pinned Parallel orchestration with only IPC ABI/safety adaptation |
| B | run_scheduler_comparison.py --scheduler parallel | ABI-corrected unified Parallel |
| C | run_scheduler_comparison.py --scheduler serial | ABI-corrected unified Serial |

A1 preserves the original generator, feedback, error classification, budget and
statistics implementation. Its wrapper observes process launches for cleanup
and identifies the original normal footer; it does not replace that footer with
the unified counter. A budget-truncated, retested or incomplete A1 run is rejected
at acceptance, not repaired by subtracting one from a counter.

B/C share the same ABI layer, native executor, runtime binary, calibration,
feedback processing and unified accounting. Their intended scheduler and
period/depth mapping differences remain as documented in the pilot report.

A1/B must have identical actual schedule sequences, observed yield writes,
error records, counts and ABI/layer identity before C can run. Their comparison
does not require agreement with the historical 27/6 path; historical differences
are recorded explicitly. Serial is compared with the paper only after measuring
it. The original input, all raw outputs and failed gates are retained.

## Proof and source provenance gates

The v2 preflight repeats actual executable and actual existing-object DWARF
inspection and requires identical validated layouts. It rechecks fixed binary
and ConConfig hashes, source HEAD, scoped clean status, all pinned Python/runtime
source bytes and the actual raw-driver static expressions. Driver metadata must
bind its layout to that proof. The proof also binds the exact unified driver,
ABI-only reference entry and common ABI module files; both entry points rehash
their actually loaded code before any target launch.

The raw-source audit reads the extracted/current file using AST, without
importing or executing it. It checks MAP_SIZE, scalar/array receiving types,
all field read offsets and lengths, and the yield writer. Unrecognized source
expressions are unverifiable, not assumed compatible. A recognized incompatible
raw driver can be retained as historical evidence while A1/B/C use the proven
compatibility layer; it cannot be mislabeled as an unmodified runnable reference.

New source patches are `docs/patches/table2-abi-reference.patch`,
`table2-abi-parallel.patch` and `table2-abi-serial.patch`. These are complete review
diffs against the immutable pinned original; helper code is also required. They
must not be applied over the historical container's original files. The previous
non-ABI patches and historical checksums were retained.

## Tests and next actual execution

The final test logs and verification JSON under
`docs/results/table2-abi-compatibility-20261124/` are authoritative. The exact
previous **81 test IDs** are selected and verified independently, and all tests
run again together. New tests use the actual binary layout fixture plus guarded
local buffers, boundary/canary checks, static driver execution with fake I/O,
v2-proof tampering, and evidence provenance checks. No offline test is a real
container or target measurement.

Final recorded result: **141 tests passed**, comprising the original 81 and
60 new ABI-specific tests. All original 81 test IDs remain present, and the six
original test files still match their previous SHA-256 values byte for byte.
The eight implementation Python files also pass Python 3.6 grammar parsing;
test execution was host Python 3.12.4. Linux Bash/native execution remains a
mandatory pending gate, not an offline test success.

First extract and audit the real historical source in Ubuntu:

```bash
cd /mnt/e/cs340-period-replication
sudo -v
python3 scripts/resume_table2_podman.py --extract-only
```

This copies the actual driver/modules/runtime source and resolves copied HEAD
metadata while the container is stopped. It writes an extraction audit, source
hashes and raw ABI-expression report to a fresh evidence directory. It does not
pretend to observe the complete live Git worktree status while stopped.

The complete next pre-experiment command is:

```bash
cd /mnt/e/cs340-period-replication
sudo -v
python3 scripts/resume_table2_podman.py --execute
```

That command also performs extraction first. It only starts the inspected idle
shell container after source/layout gates, records actual live source status and
configuration, runs Linux/Bash/tests/proof/permissions/IPC gates, then A1/B/C in
sequence. It recognizes Podman 3.4.4's actual single-path Entrypoint string and
duplicate argv0 representation strictly; unknown shell command strings remain
blocked. It does not upgrade capabilities or start v2 as a silent substitute.

All new evidence is saved to `docs/results/table2-rootful-resume-*` with a
`resume-summary.json`, `RESUME_REPORT.md`, raw native evidence and SHA256SUMS.
No original container, binary, object, core source or historical output is
deleted, overwritten, recompiled or replaced. No Git Commit/Push occurs.

**Current conclusion:** ABI compatibility code is available for review; actual
historical source audit and live v2 proof/A1/B/C remain pending Ubuntu execution.
Formal four-program batches are not authorized by these offline results.
