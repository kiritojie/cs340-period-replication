# Focused cleanup repair and staged real acceptance

The independent entry is `scripts/table2_permission_stage.py`. It uses only the
already running, fixed original container. It does not repeat historical file
extraction or start a Benchmark in its default permissions stage.

Run from the **Ubuntu root terminal**:

```bash
cd /mnt/e/cs340-period-replication
python3 scripts/table2_permission_stage.py --permissions-only
```

This creates a unique evidence/session directory, checks the actual current
container and live state, copies the current harness to a new temporary
directory, runs the focused Linux cleanup regressions, then performs real TERM,
timeout KILL, process-group/descendant and SCHED_DEADLINE acceptance. It exports
the complete native records. A nonzero exit or `BLOCKED` never authorizes A1.

Only after `Final status: PERMISSIONS_PASSED`, use the exact printed **Session**
path in the next command:

```bash
python3 scripts/table2_permission_stage.py --pilot --session /mnt/e/cs340-period-replication/docs/results/table2-permission-stage-TIMESTAMP-SUFFIX
```

The pilot stage reuses that session's measured permission proof and staged
harness only while all recorded identities still match. Container restart
(PID/start time), launch-configuration changes or harness changes require a new
permissions session. Actual credentials/capabilities, CPU affinity, active
processes and IPC state are checked again; they are never replaced by cached
values. The existing pilot performs its current ABI/provenance and test checks,
then A1, B and C in order; C still requires A1/B regression equality.

Each pilot attempt creates a fresh evidence directory. The command runs only
`reorder_3`; it does not build programs, change runtime/ABI/core algorithms,
change container privileges, alter sudoers, delete IPC, overwrite historical
results, commit or push. Preserve the printed status, Session and Evidence
lines after either stage.
