# Curated Table 2 RQ1 text evidence

All original members retain exact bytes at repository-relative paths.
PACKAGE_SHA256SUMS covers every included original file, including out_*/Errors
and ConConfig evidence that normal Git rules ignore. PACKAGE_OMISSIONS.json
lists compiled/cache/array copies excluded from this package by path/size/SHA.
Complete originals remain locally unchanged and passed full manifest checks.
After curated extraction, original manifests referring to omitted artifacts
cannot all pass; use PACKAGE_SHA256SUMS for included-file integrity.
Canonical raw formal/adaptation/recovery evidence, historical-source extraction,
the successful pilot and necessary failed export/setup records are included.
Duplicate older sessions/preparation copies remain local. Final batch,
statistics and charts are regular repository files outside this ZIP.
