# Root-direct permission compatibility review

Status: **OFFLINE_VERIFIED_LIVE_ACCEPTANCE_PENDING**

The historical sudo-probe is the confirmed blocker: wrapper exit 2, sudo
setresuid denied. Actual container UID/GID are zero, all five capability masks
are SYS_NICE (0x800000), NoNewPrivs=1 and Seccomp=2. The original Linux 141-test
suite and ABI proof passed; no A1/B/C target started.

Historical integrity: all 291 top-level manifest entries and 31 native entries
match. Original/post binary, config and runtime-object hashes agree. The ABI
layer, ABI preflight, evidence analyzer, trace observer and both ABI/controller
source adaptation functions remain unchanged. See failure-audit.json.

The repair changes permission/process orchestration. Root commands omit sudo;
finalized leading environment assignments become child environment entries.
Nonroot privilege commands retain sudo -n. A1/B/C share launch normalization
and process-group supervision, including dry run and preparation. Cleanup kills
owned groups even if their leader has exited, reaps adopted descendants and
restores temporary subreaper state. TERM is deferred until a newly launched
child is registered, without passing a blocked signal mask to that child.

The pilot requires measured permission-proof.json before any benchmark launch,
with before/after checks per arm. It must contain actual TERM, timeout KILL,
live/leader-exited descendant cleanup, outer-watchdog cleanup, and kernel
SCHED_DEADLINE setting/readback/yield/restoration. Helper/controller hashes and
actual UID/capability/security state are rechecked. Root skips unnecessary
sudo/chown in the host Podman bridge. Container creation configuration is
checked and never weakened. A1 retains the official timeout classification;
B/C retain their existing bounded timeout handling. Any target timeout still
fails pilot acceptance.

Validation here: **164 offline tests passed, including all original 141 and
23 new permission tests**. Changed Python files pass Python 3.6 grammar checks.
These offline tests do not certify live Linux permissions.

The read-only WSL access attempt returned Wsl/E_ACCESSDENIED; command/output
are preserved. Native permission acceptance, Linux bash syntax checking of the
new wrapper and A1/B/C were not executed in this session. Real acceptance
remains pending and any failed gate must remain BLOCKED.

Run in the Ubuntu root terminal:

```bash
cd /mnt/e/cs340-period-replication
python3 scripts/resume_table2_podman.py --execute
```

This creates fresh evidence, reruns Linux syntax/tests/ABI/permission gates,
then sequentially runs the authorized reorder_3 A1/B/C pilot. C requires A1/B
agreement. No formal batch, rebuild, container creation, privileged flag, extra
capability, sudoers edit, security relaxation, history overwrite, commit or
push was performed.
