# Rootful Podman reorder_3 resume

Status: **EXTRACTED_FOR_REVIEW_NO_BENCHMARK**

| Arm | Validation | First bug | Total | Buggy | Timeouts |
| --- | --- | ---: | ---: | ---: | ---: |
| A0 | AUDIT_ONLY_NOT_RUN | None | None | None | None |
| A1 | NOT_RUN_OR_UNVERIFIED | None | None | None | None |
| B | NOT_RUN_OR_UNVERIFIED | None | None | None | None |
| C | NOT_RUN_OR_UNVERIFIED | None | None | None | None |

Reference only: historical Parallel 6/27/6/0; Serial paper 10/30/10. These are not measured values.

A0 is historical-source audit only. A1, when present, is an ABI-only corrected Parallel reference, not the unchanged old driver.

Actual launch configuration, masks, original-product hashes and all command outputs are preserved.
Restarting the old container preserves its writable layer and creation configuration; process/IPC state is freshly observed.
No formal four-program batch was started. A passed pilot is for human review, not automatic batch authorization.
See resume-summary.json and native-evidence for the full result and any blocking reason.
