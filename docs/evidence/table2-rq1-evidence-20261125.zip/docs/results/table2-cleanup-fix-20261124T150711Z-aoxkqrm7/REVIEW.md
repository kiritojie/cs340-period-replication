# Focused cleanup repair

Status: **FOCUSED_FIX_OFFLINE_VERIFIED_NATIVE_PENDING**

This revision addresses the repeated `communicate()` failure observed in
`table2-rootful-resume-20261124T225617-9f5euqdl`. It does not change the ABI
compatibility layer, official generators/controller adaptations, original
binary/runtime, or container permissions.

- Central cleanup still signals the owned group even after its leader exits.
- Fully closed/drained pipes use bounded wait and cached results; partially
  closed pipes drain only the open side. They are not passed back to communicate.
- Probe results, raw stdout/stderr, observed exit codes and kernel fields are
  retained. Cleanup errors are separate, include full tracebacks and keep the
  overall gate BLOCKED. Per-probe raw sidecars are exported with the proof.
- The two drivers now preserve cleanup tracebacks in metadata. Their official
  ABI/controller source transformation functions remain identical.
- A small standalone entry runs focused native cleanup tests and real
  permissions without repeating historical extraction or running a benchmark.
  An explicit second invocation reuses that session and existing pilot logic.
  Runtime PID/start time, configuration, harness hashes, actual credentials,
  affinity, IPC and active processes are rechecked. Failures remain BLOCKED.

Validation: **176 tests discovered; 172 passed and 4 real Linux subprocess
tests explicitly skipped on Windows**. All original 164 test identities remain
present, and their Python source files are byte-identical to the prior verified
harness. Changed Python files pass Python 3.6 grammar checks. Native execution
remains pending because the read-only WSL access attempt returned
`Wsl/E_ACCESSDENIED`. No native permission PASS or A1/B/C result is claimed.

The four native regressions cover drained/closed pipes, repeated cleanup,
timeout KILL, a partially closed pipe, and a leader that exits before its
descendant. They use harmless Python children and will run in stage one.

Ubuntu root, first run only permission acceptance:

```bash
cd /mnt/e/cs340-period-replication
python3 scripts/table2_permission_stage.py --permissions-only
```

Only after `Final status: PERMISSIONS_PASSED`, use the exact printed Session
directory (replace the placeholder below):

```bash
python3 scripts/table2_permission_stage.py --pilot --session "SESSION_PATH"
```

Stage two retains current source/product/ABI checks, executes A1 then B, and
requires their regression equality before C. Each attempt creates fresh
evidence. No other benchmark, rebuild, security relaxation, history overwrite,
commit or push was performed.
